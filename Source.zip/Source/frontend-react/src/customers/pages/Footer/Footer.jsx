function Footer(){


  return(
      <>
      <hr/>

<footer className="footer footer-center p-10  text-base-content rounded">
 
 
<div>
  <p>Copyright © 2024 - All right reserved by Zaika Foos pvt ltd</p>
  <p ><i>Made with</i> ❤️ <i>Ashwin Shelke, Apurv Jain, Gayatri Marathe, Rakesh More,Shubham Thakur </i> </p>
</div>
</footer>
      </>
  )

}

export default Footer