import {
    Avatar,
    Backdrop,
    Box,
    Button,
    Card,
    CardHeader,
    CircularProgress,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Typography,
  } from "@mui/material";
  
  import React, { useEffect } from "react";
  import { useParams } from "react-router-dom";
  
  import { useDispatch, useSelector } from "react-redux";
  import { getMenuItemsByRestaurantId } from "../../State/Customers/Menu/menu.action";
  const RestaurantTable = ({ isDashboard, name }) => {
    const dispatch = useDispatch();
     const { restaurant } = useSelector((store) => store);
    // const { id } = useParams();
    
    useEffect(() => {
      
    }, []);
  
    const handleDeleteProduct = (productId) => {
      console.log("delete product ", productId);
    };
  
    return (
      <Box width={"100%"}>
        <Card className="mt-1">
          <CardHeader
            title={name}
            sx={{
              pt: 2,
              alignItems: "center",
              "& .MuiCardHeader-action": { mt: 0.6 },
            }}
          />
          <TableContainer>
            <Table  aria-label="table in dashboard">
              <TableHead>
                <TableRow>
                  <TableCell>Banner</TableCell>
                  <TableCell>Name</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>Owner</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>Cuisine Type</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>Location</TableCell>
                  {!isDashboard && <TableCell sx={{ textAlign: "center" }}>Contact</TableCell>}
                </TableRow>
              </TableHead>
              <TableBody>
                {restaurant.restaurants.slice(0,isDashboard?7:restaurant.restaurants.length).map((item) => (
                  <TableRow
                    hover
                    key={item.name}
                    sx={{ "&:last-of-type td, &:last-of-type th": { border: 0 } }}
                  >
                    <TableCell>
                      {" "}
                      <Avatar alt={item.name} src={item.imageUrl} />{" "}
                    </TableCell>
  
                    <TableCell
                      sx={{ py: (theme) => `${theme.spacing(0.5)} !important` }}
                    >
                      <Box sx={{ display: "flex", flexDirection: "column" }}>
                        <Typography
                          sx={{
                            fontWeight: 500,
                            fontSize: "0.875rem !important",
                          }}
                        >
                          {item.name}
                        </Typography>
                        <Typography variant="caption">{item.brand}</Typography>
                      </Box>
                    </TableCell>
                    <TableCell sx={{ textAlign: "center" }}>
                      {item.owner.fullName}
                    </TableCell>
                    <TableCell sx={{ textAlign: "center" }}>
                      {item.cuisineType}
                    </TableCell>
                    <TableCell sx={{ textAlign: "center" }}>
                      {item.address.city}
                    </TableCell>
  
                    {!isDashboard && <TableCell sx={{ textAlign: "center" }}>
                      {item.contactInformation.email}
                    </TableCell>}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Card>
  
        <Backdrop
          sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open={restaurant.loading}
        >
          <CircularProgress color="inherit" />
        </Backdrop>
      </Box>
    );
  };
  
  export default RestaurantTable;


// import React, { useEffect, useState } from 'react';
// import axios from 'axios';

// const RestaurantTable = () => {
//   const [restaurants, setRestaurants] = useState([]);

//   useEffect(() => {
//     // Fetch restaurants from the API
//     axios.get('http://localhost:5454/api/admin/all-restaurants')
//       .then(response => {
//         setRestaurants(response.data);
//         console.log(response.data);
//       })
//       .catch(error => {
//         console.error('There was an error fetching the restaurants!', error);
//       });
//   }, []);

//   return (
//     <div>
//       <h2>Restaurant List</h2>
//       <table border="1">
//         <thead>
//           <tr>
//             <th>ID</th>
//             <th>Owner</th>
//             <th>Name</th>
//             <th>Cuisine Type</th>
//             <th>Address</th>
//             <th>Contact Information</th>
//             <th>Opening Hours</th>
//             <th>Number of Ratings</th>
//             <th>Registration Date</th>
//           </tr>
//         </thead>
//         <tbody>
//           {restaurants.map((restaurant) => (
//             <tr key={restaurant.id}>
//               <td>{restaurant.id}</td>
//               <td>{restaurant.owner?.name}</td>
//               <td>{restaurant.name}</td>
//               <td>{restaurant.cuisineType}</td>
//               <td>
//                 {restaurant.address?.street}, {restaurant.address?.city}, {restaurant.address?.state}, {restaurant.address?.zipCode}
//               </td>
//               <td>
//                 Phone: {restaurant.contactInformation?.phoneNumber}<br />
//                 Email: {restaurant.contactInformation?.email}
//               </td>
//               <td>{restaurant.openingHours}</td>
//               <td>{restaurant.numRating}</td>
//               <td>{new Date(restaurant.registrationDate).toLocaleDateString()}</td>
//               <td>{restaurant.open ? 'Yes' : 'No'}</td>
//             </tr>
//           ))}
//         </tbody>
//       </table>
//     </div>
//   );
// };

// export default RestaurantTable;
