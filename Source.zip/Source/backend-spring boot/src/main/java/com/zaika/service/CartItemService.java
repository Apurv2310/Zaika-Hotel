package com.zaika.service;

import com.zaika.model.CartItem;

public interface CartItemService {
	
	public CartItem createCartItem(CartItem item);

}
