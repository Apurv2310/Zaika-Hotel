package com.zaika.service;

import com.zaika.model.OrderItem;

public interface OrderItemService {
	
	public OrderItem createOrderIem (OrderItem orderItem);

}
